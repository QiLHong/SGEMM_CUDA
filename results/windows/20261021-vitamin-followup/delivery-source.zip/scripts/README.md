# 脚本怎么选

第一次来，不要挨个运行脚本。先读[代码与脚本使用索引](../docs/zh/23-代码与脚本使用索引.md)：
它解释此前整理的 122 个代码/配置文件并补充 Windows 入口，包含术语、调用关系、最小 K30 路线、结果读法和危险入口。

Windows 原生在仓库根目录使用 PowerShell 7：

```powershell
.\scripts\windows\Build.ps1 -WithExperiment
.\scripts\windows\Run-Benchmarks.ps1
# 可选，单独运行，避免与 benchmark 同时占用 GPU：
.\scripts\windows\Profile-Experiment.ps1
```

工具链选择、每个线程的数据流与本次实测见[Windows 教程](../docs/zh/24-Windows原生构建与4090D实验.md)。
第二阶段 K30 同步对照使用独立构建与结果目录：

```powershell
.\scripts\windows\Build.ps1 -BuildDir build-windows-k30-sync-sm89 -Architecture 89 -WithExperiment
.\scripts\windows\Run-K30Sync.ps1 -BuildDir build-windows-k30-sync-sm89
# benchmark 完成后再运行 profiler；不要并行占用 GPU：
.\scripts\windows\Profile-K30Sync.ps1 -BuildDir build-windows-k30-sync-sm89
```

不传 `OutputDir` 时脚本创建新的时间戳目录；指定已有目录会拒绝覆盖。
`Run-K30Sync.ps1` 自动调用 `Summarize-Results.ps1` 与 `Summarize-Telemetry.ps1`；
完整 CPU 映射、静态分析命令及指标单位见[第 25 章](../docs/zh/25-K30同步机制与4090D性能分析.md)。
以下 `.sh` 和历史复现说明继续保留为 Linux 入口。

## 常用顺序

第三阶段 vitamin SIMT 原生复现（A 为原数学配置，B 为严格 FP32）：

```powershell
.\scripts\windows\Build-Vitamin.ps1
$result = "results\windows\$(Get-Date -Format 'yyyyMMdd-HHmmss')-vitamin-simt"
.\scripts\windows\Run-Vitamin.ps1 -OutputDir $result
.\scripts\windows\Summarize-Vitamin.ps1 -ResultDir $result
.\scripts\windows\Profile-Vitamin.ps1 -OutputDir "$result-profile"
```

以上在仓库根目录的 PowerShell 7 执行。全部结果为 `C=AB`，不与第二阶段 `alpha=0.5,beta=3` 直接拼表。
原生入口无 PyTorch 依赖。另有 `Run-VitaminPython.ps1` 使用现有 `envs/pytorch` 环境，经过 Windows 包装适配复用原 Python 计时/校验函数，墙钟数据单独归档；不执行原默认 TF32 测试。源码来源、线程映射、原始数据与静态分析命令见[第 26 章](../docs/zh/26-vitamin-SIMT复现与K30公平对照.md)。

```text
build     编译源码，得到可执行文件与资源日志
correctness  对同输入的严格 FP32 参考验算
memcheck / sync  检查访存、竞争与同步
fair      多轮交错计时，保存原始 CSV
profile / source  用 Nsight 解释硬件行为
analyze / summarize  读证据、统计并归档
```

当前最佳研究基线 K30 V2：从 [build_k30_audit.sh](build_k30_audit.sh) 和
[run_k30_audit.py](run_k30_audit.py) 开始。最小命令在上面的总索引中。
完整收尾复现使用包含 K10/K30/K32 的独立 harness，见[复现文档](../docs/zh/20-项目复现与简历讲述.md)。

每个文件顶部注明输入、输出、运行条件和覆盖范围，关键函数旁解释为什么这样做。
`.cu` 需要编译，`.sh` 用 Bash，`.py` 用 Python；`audit` 是编译出的程序，不是目录里的源文件。

## 先避开这些误用

- `kernel_9/10/11_autotuner.sh` 会原地改源码；先读，别直接跑。
- 旧绘图器会覆盖 README 和图片；不用它生成当前 strict FP32 研究结论。
- 输出目录已存在时换新名字，不删除旧结果。
- 只看到 GFLOPS 不等于实验成功；还要看 PASS、工具摘要、测试范围与日志是否齐全。
- 先串行验证，再计时；不要同时跑 profiler 与 benchmark。
