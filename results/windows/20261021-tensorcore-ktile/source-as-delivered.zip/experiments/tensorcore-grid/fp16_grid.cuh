// Original author: QiLHong / vitamin-cuda; see ../tensorcore/vendor/LICENSE.
// Source commit 520f97093a2abc239977be83d244b327d0e2e2ef, kernels/hgemm/hgemm.cu
// EXPERIMENT: only grid width is parameterized; not an unchanged upstream kernel.
#pragma once
#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <cuda_bf16.h>
#include <cstdint>
#include <type_traits>
#include "../tensorcore/vendor/pack.cuh"
namespace grid_fp16 {
#define SWIZZLE_A(row, col) ((col) ^ (((row >> 1) & 0x3) << 3))

#define SWIZZLE_B(row, col) ((col) ^ (((row) & 0x7) << 3))

#define SWIZZLE_C(row, col) ((col) ^ (((row) & 0x7) << 3))

// ---------------- Inline PTX assembly macros ----------------
// cp.async: async 16-byte copy from gmem (src) to smem (dst_smem_32b)
#define CP_ASYNC_CG(dst_smem_32b, src_global_ptr)                                                                      \
    asm volatile("cp.async.cg.shared.global.L2::128B [%0], [%1], 16;\n" ::"r"(dst_smem_32b), "l"(src_global_ptr))

#define CP_ASYNC_COMMIT_GROUP() asm volatile("cp.async.commit_group;\n" ::)
#define CP_ASYNC_WAIT_GROUP_0() asm volatile("cp.async.wait_group 0;\n" ::)

// ldmatrix
#define LDMATRIX_X4(R0, R1, R2, R3, PTR)                                                                               \
    asm volatile("ldmatrix.sync.aligned.m8n8.x4.shared.b16 {%0, %1, %2, %3}, [%4];"                                    \
                 : "=r"(R0), "=r"(R1), "=r"(R2), "=r"(R3)                                                              \
                 : "r"(PTR))

#define LDMATRIX_X2(R0, R1, PTR)                                                                                       \
    asm volatile("ldmatrix.sync.aligned.m8n8.x2.shared.b16 {%0, %1}, [%2];" : "=r"(R0), "=r"(R1) : "r"(PTR))

// Load two 8x8 tiles and transpose
#define LDMATRIX_X2_TRANS(R0, R1, PTR)                                                                                 \
    asm volatile("ldmatrix.sync.aligned.m8n8.x2.trans.shared.b16 {%0, %1}, [%2];" : "=r"(R0), "=r"(R1) : "r"(PTR))

// mma.sync
#define M16N8K16_F16(C0, C1, C2, C3, A0, A1, A2, A3, B0, B1)                                                           \
    asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 "                                                  \
                 "{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%10,%11,%12,%13};\n"                                         \
                 : "=f"(C0), "=f"(C1), "=f"(C2), "=f"(C3)                                                              \
                 : "r"(A0), "r"(A1), "r"(A2), "r"(A3), "r"(B0), "r"(B1), "f"(C0), "f"(C1), "f"(C2), "f"(C3))

#define M16N8K16_BF16(C0, C1, C2, C3, A0, A1, A2, A3, B0, B1)                                                          \
    asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 "                                                \
                 "{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%10,%11,%12,%13};\n"                                         \
                 : "=f"(C0), "=f"(C1), "=f"(C2), "=f"(C3)                                                              \
                 : "r"(A0), "r"(A1), "r"(A2), "r"(A3), "r"(B0), "r"(B1), "f"(C0), "f"(C1), "f"(C2), "f"(C3))

// ------------------------------------------ ldmatrix + mma  ----------------------------------------------------

// a block calculate c[128][128]
template <const int GRID_W, const int BM = 128, const int BN = 128, const int BK = 32, typename T>
__global__ void hgemm_bcf_dbf_rw_kernel(T *a, T *b, T *c, int m, int n, int k) {
    // grid swizzling
    int linear_id = blockIdx.y * gridDim.x + blockIdx.x;
    const int SWIZZLE_W = GRID_W; // swizzle / logical width = 8

    int bx = (linear_id % SWIZZLE_W) + (linear_id / (SWIZZLE_W * gridDim.y)) * SWIZZLE_W;
    int by = (linear_id / SWIZZLE_W) % gridDim.y;

    int tid = threadIdx.x; // 0~255
    int warp_id = tid / WARP_SIZE;
    int lane_id = tid % WARP_SIZE;

    // GMEM->SMEM load indexing
    int load_a_row = tid / 4;        // 0~63
    int load_a_col = (tid % 4) * 8;  // 0,8,16,24
    int load_b_row = tid / 16;       // 0..15 (K)
    int load_b_col = (tid % 16) * 8; // 0,8,...,120 (N)

    // Layout works for both A and B; union aliases one smem block for A/B then C
    __shared__ __align__(128) union {
        // First phase: A and B tiles
        struct {
            T As[2][BM][BK];
            T Bs[2][BK][BN];
        };
        // Second phase: C writeback buffer
        T Cs[BM][BN];
    } smem;

    // warp tiling
    // Each warp owns a 64x32 C tile
    int warp_id_m = warp_id / 4; // 0, 1
    int warp_id_n = warp_id % 4; // 0, 1, 2, 3

    // Accumulators: 4 M-fragments * 4 N-fragments * 4 float regs = 64
    float sum[4][4][4] = {0.f};

    // ----------------------------- Prologue: prefetch As/Bs once
    // cp.async load A
    uint32_t smem_a0 =
        static_cast<uint32_t>(__cvta_generic_to_shared(&smem.As[0][load_a_row][SWIZZLE_A(load_a_row, load_a_col)]));
    uint32_t smem_a1 = static_cast<uint32_t>(
        __cvta_generic_to_shared(&smem.As[0][load_a_row + 64][SWIZZLE_A(load_a_row + 64, load_a_col)]));

    T *global_a0 = &a[(by * BM + load_a_row) * k + load_a_col];
    T *global_a1 = &a[(by * BM + load_a_row + 64) * k + load_a_col];

    CP_ASYNC_CG(smem_a0, global_a0);
    CP_ASYNC_CG(smem_a1, global_a1);

    // cp.async load B
    uint32_t smem_b0 =
        static_cast<uint32_t>(__cvta_generic_to_shared(&smem.Bs[0][load_b_row][SWIZZLE_B(load_b_row, load_b_col)]));
    uint32_t smem_b1 = static_cast<uint32_t>(
        __cvta_generic_to_shared(&smem.Bs[0][load_b_row + 16][SWIZZLE_B(load_b_row + 16, load_b_col)]));

    T *global_b0 = &b[(load_b_row)*n + bx * BN + load_b_col];
    T *global_b1 = &b[(load_b_row + 16) * n + bx * BN + load_b_col];

    CP_ASYNC_CG(smem_b0, global_b0);
    CP_ASYNC_CG(smem_b1, global_b1);

    CP_ASYNC_COMMIT_GROUP();
    CP_ASYNC_WAIT_GROUP_0();
    __syncthreads();

    int read_idx = 0;
    int write_idx = 1;

    // Main K loop
    for (int bk = 32; bk < k; bk += BK) {

        // 1. cp.async load A
        smem_a0 = static_cast<uint32_t>(
            __cvta_generic_to_shared(&smem.As[write_idx][load_a_row][SWIZZLE_A(load_a_row, load_a_col)]));
        smem_a1 = static_cast<uint32_t>(
            __cvta_generic_to_shared(&smem.As[write_idx][load_a_row + 64][SWIZZLE_A(load_a_row + 64, load_a_col)]));

        // Strided global pointers to ease register pressure
        global_a0 += BK;
        global_a1 += BK;

        CP_ASYNC_CG(smem_a0, global_a0);
        CP_ASYNC_CG(smem_a1, global_a1);

        // 2. cp.async load B
        smem_b0 = static_cast<uint32_t>(
            __cvta_generic_to_shared(&smem.Bs[write_idx][load_b_row][SWIZZLE_B(load_b_row, load_b_col)]));
        smem_b1 = static_cast<uint32_t>(
            __cvta_generic_to_shared(&smem.Bs[write_idx][load_b_row + 16][SWIZZLE_B(load_b_row + 16, load_b_col)]));

        global_b0 += BK * n;
        global_b1 += BK * n;

        CP_ASYNC_CG(smem_b0, global_b0);
        CP_ASYNC_CG(smem_b1, global_b1);

        CP_ASYNC_COMMIT_GROUP();

        // 3. Tensor Core: two K steps, 16 elements each
#pragma unroll
        for (int k_step = 0; k_step < 2; ++k_step) {
            int k_offset = k_step * 16;

            uint32_t reg_a[4][4];
            uint32_t reg_b[4][2];

            // Four ldmatrix.issue for A (4 * 16 = 64 rows)
#pragma unroll
            for (int m_idx = 0; m_idx < 4; ++m_idx) {
                // ldmatrix x4 loads a 16x16 tile
                int a_row = warp_id_m * 64 + m_idx * 16 + (lane_id % 16);
                int a_col = k_offset + (lane_id / 16) * 8;
                uint32_t smem_addr =
                    static_cast<uint32_t>(__cvta_generic_to_shared(&smem.As[read_idx][a_row][SWIZZLE_A(a_row, a_col)]));
                LDMATRIX_X4(reg_a[m_idx][0], reg_a[m_idx][1], reg_a[m_idx][2], reg_a[m_idx][3], smem_addr);
            }

            // Four ldmatrix.issue for B (4 * 8 = 32 columns)
#pragma unroll
            for (int n_idx = 0; n_idx < 4; ++n_idx) {
                // Lanes 0-15 load 16 rows (bases of two 8x8 tiles)
                int b_row = k_offset + (lane_id % 16);
                int b_col = warp_id_n * 32 + n_idx * 8;

                uint32_t smem_addr =
                    static_cast<uint32_t>(__cvta_generic_to_shared(&smem.Bs[read_idx][b_row][SWIZZLE_B(b_row, b_col)]));
                LDMATRIX_X2_TRANS(reg_b[n_idx][0], reg_b[n_idx][1], smem_addr);
            }

            // MMA body: 4x4 m16n8k16
#pragma unroll
            for (int m_idx = 0; m_idx < 4; ++m_idx) {
#pragma unroll
                for (int n_idx = 0; n_idx < 4; ++n_idx) {
                    if constexpr (std::is_same_v<T, __half>) {
                        M16N8K16_F16(sum[m_idx][n_idx][0],
                                     sum[m_idx][n_idx][1],
                                     sum[m_idx][n_idx][2],
                                     sum[m_idx][n_idx][3],
                                     reg_a[m_idx][0],
                                     reg_a[m_idx][1],
                                     reg_a[m_idx][2],
                                     reg_a[m_idx][3],
                                     reg_b[n_idx][0],
                                     reg_b[n_idx][1]);
                    } else {
                        M16N8K16_BF16(sum[m_idx][n_idx][0],
                                      sum[m_idx][n_idx][1],
                                      sum[m_idx][n_idx][2],
                                      sum[m_idx][n_idx][3],
                                      reg_a[m_idx][0],
                                      reg_a[m_idx][1],
                                      reg_a[m_idx][2],
                                      reg_a[m_idx][3],
                                      reg_b[n_idx][0],
                                      reg_b[n_idx][1]);
                    }
                }
            }
        }
        CP_ASYNC_WAIT_GROUP_0();
        __syncthreads();
        read_idx ^= 1;
        write_idx ^= 1;
    }
    // ------------------- Epilogue: final MMA, then store C
#pragma unroll
    for (int k_step = 0; k_step < 2; ++k_step) {
        int k_offset = k_step * 16;

        uint32_t reg_a[4][4];
        uint32_t reg_b[4][2];

        // Four ldmatrix.issue for A (4 * 16 = 64 rows)
#pragma unroll
        for (int m_idx = 0; m_idx < 4; ++m_idx) {
            // ldmatrix x4 loads a 16x16 tile
            int a_row = warp_id_m * 64 + m_idx * 16 + (lane_id % 16);
            int a_col = k_offset + (lane_id / 16) * 8;
            uint32_t smem_addr =
                static_cast<uint32_t>(__cvta_generic_to_shared(&smem.As[read_idx][a_row][SWIZZLE_A(a_row, a_col)]));
            LDMATRIX_X4(reg_a[m_idx][0], reg_a[m_idx][1], reg_a[m_idx][2], reg_a[m_idx][3], smem_addr);
        }

        // Four ldmatrix.issue for B (4 * 8 = 32 columns)
#pragma unroll
        for (int n_idx = 0; n_idx < 4; ++n_idx) {
            // Lanes 0-15 load 16 rows (bases of two 8x8 tiles)
            int b_row = k_offset + (lane_id % 16);
            int b_col = warp_id_n * 32 + n_idx * 8;

            uint32_t smem_addr =
                static_cast<uint32_t>(__cvta_generic_to_shared(&smem.Bs[read_idx][b_row][SWIZZLE_B(b_row, b_col)]));
            LDMATRIX_X2_TRANS(reg_b[n_idx][0], reg_b[n_idx][1], smem_addr);
        }

        // MMA body: 4x4 m16n8k16
#pragma unroll
        for (int m_idx = 0; m_idx < 4; ++m_idx) {
#pragma unroll
            for (int n_idx = 0; n_idx < 4; ++n_idx) {
                if constexpr (std::is_same_v<T, __half>) {
                    M16N8K16_F16(sum[m_idx][n_idx][0],
                                 sum[m_idx][n_idx][1],
                                 sum[m_idx][n_idx][2],
                                 sum[m_idx][n_idx][3],
                                 reg_a[m_idx][0],
                                 reg_a[m_idx][1],
                                 reg_a[m_idx][2],
                                 reg_a[m_idx][3],
                                 reg_b[n_idx][0],
                                 reg_b[n_idx][1]);
                } else {
                    M16N8K16_BF16(sum[m_idx][n_idx][0],
                                  sum[m_idx][n_idx][1],
                                  sum[m_idx][n_idx][2],
                                  sum[m_idx][n_idx][3],
                                  reg_a[m_idx][0],
                                  reg_a[m_idx][1],
                                  reg_a[m_idx][2],
                                  reg_a[m_idx][3],
                                  reg_b[n_idx][0],
                                  reg_b[n_idx][1]);
                }
            }
        }
    }

    // ---------------- Store C ----------------
    // Reuse As/Bs smem as staging for C stores
    __syncthreads();

    int t_row = lane_id / 4;       // 0~7
    int t_col = (lane_id % 4) * 2; // 0, 2, 4, 6

    // register to Cs smem
#pragma unroll
    for (int m_idx = 0; m_idx < 4; ++m_idx) {
#pragma unroll
        for (int n_idx = 0; n_idx < 4; ++n_idx) {
            int c_base_row = warp_id_m * 64 + m_idx * 16; // M: 16-row span
            int c_base_col = warp_id_n * 32 + n_idx * 8;  // N: 8-column span

            // Store 16 rows in two 8-row passes
            int c_row_0 = c_base_row + t_row;
            int c_row_2 = c_base_row + t_row + 8;
            int c_col = c_base_col + t_col;

            if constexpr (std::is_same_v<T, __half>) {
                HALF2(smem.Cs[c_row_0][SWIZZLE_C(c_row_0, c_col)]) = __float22half2_rn(FLOAT2(sum[m_idx][n_idx][0]));
                HALF2(smem.Cs[c_row_2][SWIZZLE_C(c_row_2, c_col)]) = __float22half2_rn(FLOAT2(sum[m_idx][n_idx][2]));
            } else {
                BFLOAT2(smem.Cs[c_row_0][SWIZZLE_C(c_row_0, c_col)]) =
                    __float22bfloat162_rn(FLOAT2(sum[m_idx][n_idx][0]));
                BFLOAT2(smem.Cs[c_row_2][SWIZZLE_C(c_row_2, c_col)]) =
                    __float22bfloat162_rn(FLOAT2(sum[m_idx][n_idx][2]));
            }
        }
    }

    __syncthreads();

    // smem to gmem
    // Each thread moves 64 elems (fp16/bf16) == 8 float4; one warp moves 32*4*4 = 512 B; 256 threads -> 4096 B
    T *c_block = &c[by * BM * n + bx * BN];

#pragma unroll
    for (int step = 0; step < 8; ++step) {
        // Keep elem_idx contiguous within the warp (coalesced)
        int elem_idx = (step * 256 + tid) * 8;
        int row = elem_idx / 128;
        int col = elem_idx % 128;

        int s_col = SWIZZLE_C(row, col);

        FLOAT4(c_block[row * n + col]) = FLOAT4(smem.Cs[row][s_col]);
    }
}

}
#undef SWIZZLE_A
#undef SWIZZLE_B
#undef SWIZZLE_C
#undef CP_ASYNC_CG
#undef CP_ASYNC_COMMIT_GROUP
#undef CP_ASYNC_WAIT_GROUP_0
#undef LDMATRIX_X4
#undef LDMATRIX_X2
#undef LDMATRIX_X2_TRANS
#undef M16N8K16_F16
#undef M16N8K16_BF16
